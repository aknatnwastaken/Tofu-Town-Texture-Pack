Changelog (Beginning Beta 0.4)

Beta 0.4
Added an Official Changelog
Added Tofu Coral Block
Added EvillCactus
Added Shayzis's Suggestion: Steve Villager (mildly cursed)
Fixed Diamond Ore Texture
Added Mr_Panky Zombie Villager
